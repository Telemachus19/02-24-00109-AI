package puzzle8;

public enum Action {
    Up,Down,Left,Right
}
